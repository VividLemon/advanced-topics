<template>
      <div id="nav">
        <router-link to="/">Home</router-link>|
        <router-link to="/Employees">Employees</router-link>|
      </div>
</template>


var app = new Vue({
    el: "#app", 
    data: {
        product: 'Socks', 
        image: '../2.Attributes/socks.png',
        inStock: true,
        inventory: 6
    }
})